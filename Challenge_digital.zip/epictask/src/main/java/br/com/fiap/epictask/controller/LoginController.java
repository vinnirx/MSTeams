package br.com.fiap.epictask.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.fiap.epictask.model.Login;
import br.com.fiap.epictask.repository.LoginRepository;



@Controller
public class LoginController {
	
	@Autowired
	private LoginRepository loginRepository;
	
	@GetMapping("/login")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView("logins");
		List<Login> logins = loginRepository.findAll();
		modelAndView.addObject("logins", logins);
		return modelAndView;
	}
	
	@PostMapping("/login")
	public String save(@Valid Login login, BindingResult result) {
		if (result.hasErrors()) return "login";
		loginRepository.save(login);
		return "logins";
	}
	
	@RequestMapping("/login/new")
	public String create(Login login) {
		return "login";
	}
	
	
	
}
