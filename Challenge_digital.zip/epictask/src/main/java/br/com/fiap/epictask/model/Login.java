package br.com.fiap.epictask.model;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
@Entity
public class Login {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "O campo nome é obrigatório")
	private String name;
	
	@Email
	private String email;
	
	@Min(value = 8, message = "A senha deve ter no minimo 8 caracteres ")
	private String password;

	@Size(min=15, message = "A descrição deve ter pelo menos 15 caracteres")
	private String description;
}
